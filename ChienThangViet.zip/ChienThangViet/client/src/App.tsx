import { useEffect } from "react";
import { useGameState } from "./lib/stores/useGameState";
import { useAudio } from "./lib/stores/useAudio";
import GameCanvas from "./components/GameCanvas";
import GameUI from "./components/GameUI";
import StartScreen from "./components/StartScreen";
import GameOverScreen from "./components/GameOverScreen";
import VictoryScreen from "./components/VictoryScreen";
import "@fontsource/inter";

function App() {
  const { gameState, initializeGame } = useGameState();
  const { setBackgroundMusic, setHitSound, setSuccessSound } = useAudio();

  // Initialize audio on component mount
  useEffect(() => {
    const initAudio = async () => {
      try {
        // Load background music
        const bgMusic = new Audio('/sounds/background.mp3');
        bgMusic.loop = true;
        bgMusic.volume = 0.3;
        setBackgroundMusic(bgMusic);

        // Load sound effects
        const hitSfx = new Audio('/sounds/hit.mp3');
        hitSfx.volume = 0.5;
        setHitSound(hitSfx);

        const successSfx = new Audio('/sounds/success.mp3');
        successSfx.volume = 0.5;
        setSuccessSound(successSfx);

        console.log('Audio initialized');
      } catch (error) {
        console.error('Failed to initialize audio:', error);
      }
    };

    initAudio();
    initializeGame();
  }, [setBackgroundMusic, setHitSound, setSuccessSound, initializeGame]);

  return (
    <div style={{ 
      width: '100vw', 
      height: '100vh', 
      position: 'relative', 
      overflow: 'hidden',
      background: 'linear-gradient(to bottom, #87CEEB 0%, #98FB98 100%)'
    }}>
      {gameState === 'menu' && <StartScreen />}
      {gameState === 'playing' && (
        <>
          <GameCanvas />
          <GameUI />
        </>
      )}
      {gameState === 'gameOver' && <GameOverScreen />}
      {gameState === 'victory' && <VictoryScreen />}
    </div>
  );
}

export default App;
