import React, { useRef, useEffect, useCallback } from 'react';
import { useGameState } from '../lib/stores/useGameState';
import { GameEngine } from '../lib/game/GameEngine';

const GameCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameEngineRef = useRef<GameEngine | null>(null);
  const animationFrameRef = useRef<number>();
  const { setGameState, addScore, setHealth, setLevel } = useGameState();

  // Game loop
  const gameLoop = useCallback(() => {
    if (gameEngineRef.current && canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d');
      if (ctx) {
        gameEngineRef.current.update();
        gameEngineRef.current.render(ctx);
        
        // Update game state based on engine state
        const engine = gameEngineRef.current;
        setHealth(engine.player.health);
        setLevel(engine.currentLevel);
        
        // Check game over conditions
        if (engine.player.health <= 0) {
          setGameState('gameOver');
          return;
        }
        
        // Check victory condition
        if (engine.gameComplete) {
          setGameState('victory');
          return;
        }
      }
    }
    animationFrameRef.current = requestAnimationFrame(gameLoop);
  }, [setGameState, setHealth, setLevel]);

  // Handle keyboard input
  const handleKeyDown = useCallback((event: KeyboardEvent) => {
    if (gameEngineRef.current) {
      gameEngineRef.current.handleKeyDown(event.key);
    }
  }, []);

  const handleKeyUp = useCallback((event: KeyboardEvent) => {
    if (gameEngineRef.current) {
      gameEngineRef.current.handleKeyUp(event.key);
    }
  }, []);

  // Handle mouse input for shooting
  const handleMouseClick = useCallback((event: MouseEvent) => {
    if (gameEngineRef.current && canvasRef.current) {
      const canvas = canvasRef.current;
      const rect = canvas.getBoundingClientRect();
      const x = event.clientX - rect.left;
      const y = event.clientY - rect.top;
      gameEngineRef.current.handleMouseClick(x, y);
    }
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Initialize game engine
    gameEngineRef.current = new GameEngine(canvas.width, canvas.height);
    
    // Set up event listeners
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    canvas.addEventListener('click', handleMouseClick);
    
    // Start game loop
    animationFrameRef.current = requestAnimationFrame(gameLoop);

    return () => {
      // Cleanup
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      canvas.removeEventListener('click', handleMouseClick);
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [gameLoop, handleKeyDown, handleKeyUp, handleMouseClick]);

  return (
    <canvas
      ref={canvasRef}
      width={800}
      height={600}
      style={{
        display: 'block',
        margin: '0 auto',
        border: '2px solid #8B4513',
        background: 'linear-gradient(to bottom, #4169E1 0%, #87CEEB 30%, #98FB98 70%, #228B22 100%)',
        cursor: 'crosshair'
      }}
    />
  );
};

export default GameCanvas;
