import React from 'react';
import { useGameState } from '../lib/stores/useGameState';
import { useAudio } from '../lib/stores/useAudio';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { RotateCcw, Home, Skull } from 'lucide-react';

const GameOverScreen: React.FC = () => {
  const { setGameState, resetGame, score, level } = useGameState();
  const { backgroundMusic } = useAudio();

  const handleRestart = () => {
    resetGame();
    setGameState('playing');
    
    // Restart background music
    if (backgroundMusic) {
      backgroundMusic.currentTime = 0;
      backgroundMusic.play().catch(error => {
        console.log('Background music play prevented:', error);
      });
    }
  };

  const handleBackToMenu = () => {
    resetGame();
    setGameState('menu');
    
    // Stop background music
    if (backgroundMusic) {
      backgroundMusic.pause();
      backgroundMusic.currentTime = 0;
    }
  };

  const getEncouragementMessage = () => {
    if (level === 1) {
      return "Đừng nản lòng! Anh bộ đội cần rèn luyện thêm!";
    } else if (level === 2) {
      return "Tốt lắm! Hãy thử lại để vượt qua màn tiếp theo!";
    } else if (level === 3) {
      return "Xuất sắc! Chỉ còn một bước nữa đến chiến thắng!";
    } else {
      return "Đã đến gần Boss rồi! Hãy thử lại!";
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-b from-red-900 via-red-700 to-red-500">
      <div className="absolute inset-0 bg-black bg-opacity-40"></div>
      
      <Card className="w-full max-w-lg mx-4 bg-white bg-opacity-95 shadow-2xl z-10">
        <CardHeader className="text-center pb-6">
          <div className="mb-4">
            <Skull className="w-16 h-16 mx-auto text-red-600" />
          </div>
          
          <CardTitle className="text-3xl font-bold text-red-600 mb-2">
            Hy Sinh Anh Dũng!
          </CardTitle>
          
          <p className="text-lg text-gray-700">
            Anh bộ đội đã ngã xuống vì Tổ quốc
          </p>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="text-center">
            <div className="bg-gray-100 p-4 rounded-lg mb-4">
              <div className="text-2xl font-bold text-blue-600 mb-2">
                Kết quả chiến đấu
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-lg font-bold text-yellow-600">{score}</div>
                  <div className="text-sm text-gray-600">Điểm số</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-green-600">{level}</div>
                  <div className="text-sm text-gray-600">Màn chơi</div>
                </div>
              </div>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <p className="text-gray-700 italic">
                "{getEncouragementMessage()}"
              </p>
            </div>
            
            <div className="text-yellow-600 font-bold">
              "Tinh thần bất khuất của dân tộc Việt Nam!"
            </div>
          </div>
          
          <div className="flex flex-col gap-3">
            <Button
              onClick={handleRestart}
              size="lg"
              className="bg-green-600 hover:bg-green-700 text-white font-bold w-full"
            >
              <RotateCcw className="w-5 h-5 mr-2" />
              Chiến đấu lại
            </Button>
            
            <Button
              onClick={handleBackToMenu}
              variant="outline"
              size="lg"
              className="border-gray-400 hover:bg-gray-100 w-full"
            >
              <Home className="w-5 h-5 mr-2" />
              Về trang chủ
            </Button>
          </div>
          
          <div className="text-center text-sm text-gray-600">
            <p>"Không có gì quý hơn độc lập tự do"</p>
            <p className="font-bold text-red-600">- Chủ tịch Hồ Chí Minh</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default GameOverScreen;
