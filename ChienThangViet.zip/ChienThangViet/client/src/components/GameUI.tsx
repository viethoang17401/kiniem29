import React from 'react';
import { useGameState } from '../lib/stores/useGameState';
import { useAudio } from '../lib/stores/useAudio';
import { Button } from './ui/button';
import { Volume2, VolumeX, Heart } from 'lucide-react';

const GameUI: React.FC = () => {
  const { score, health, level } = useGameState();
  const { isMuted, toggleMute } = useAudio();

  return (
    <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
      {/* Top UI Bar */}
      <div className="flex justify-between items-center p-4 bg-black bg-opacity-50 text-white pointer-events-auto">
        <div className="flex items-center space-x-6">
          {/* Score */}
          <div className="flex items-center space-x-2">
            <span className="text-lg font-bold">Điểm:</span>
            <span className="text-xl font-bold text-yellow-400">{score}</span>
          </div>
          
          {/* Level */}
          <div className="flex items-center space-x-2">
            <span className="text-lg font-bold">Màn:</span>
            <span className="text-xl font-bold text-green-400">{level}</span>
          </div>
          
          {/* Health */}
          <div className="flex items-center space-x-2">
            <span className="text-lg font-bold">Máu:</span>
            <div className="flex space-x-1">
              {Array.from({ length: Math.max(0, health) }, (_, i) => (
                <Heart key={i} className="w-6 h-6 text-red-500 fill-current" />
              ))}
            </div>
          </div>
        </div>

        {/* Audio Control */}
        <Button
          variant="outline"
          size="sm"
          onClick={toggleMute}
          className="bg-black bg-opacity-50 border-white text-white hover:bg-white hover:text-black"
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </Button>
      </div>

      {/* Controls Info */}
      <div className="absolute bottom-4 left-4 bg-black bg-opacity-70 text-white p-3 rounded pointer-events-auto">
        <div className="text-sm">
          <div><strong>Di chuyển:</strong> ← → hoặc A D</div>
          <div><strong>Nhảy:</strong> ↑ hoặc W hoặc Space</div>
          <div><strong>Tấn công:</strong> Ctrl</div>
        </div>
      </div>

      {/* Vietnamese Flag in corner */}
      <div className="absolute top-4 right-4 w-16 h-12 border-2 border-yellow-400 pointer-events-none">
        <div className="w-full h-full bg-red-600 relative">
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
            <div className="text-yellow-400 text-xl">★</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GameUI;
