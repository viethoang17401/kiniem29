import React from 'react';
import { useGameState } from '../lib/stores/useGameState';
import { useAudio } from '../lib/stores/useAudio';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Play, Volume2, VolumeX } from 'lucide-react';

const StartScreen: React.FC = () => {
  const { setGameState, resetGame } = useGameState();
  const { isMuted, toggleMute, backgroundMusic } = useAudio();

  const handleStartGame = () => {
    resetGame();
    setGameState('playing');
    
    // Start background music
    if (backgroundMusic && !isMuted) {
      backgroundMusic.currentTime = 0;
      backgroundMusic.play().catch(error => {
        console.log('Background music play prevented:', error);
      });
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-b from-blue-400 via-green-400 to-green-600">
      <div className="absolute inset-0 bg-black bg-opacity-20"></div>
      
      <Card className="w-full max-w-2xl mx-4 bg-white bg-opacity-95 shadow-2xl z-10">
        <CardHeader className="text-center pb-6">
          <div className="mb-4">
            {/* Vietnamese Flag */}
            <div className="w-24 h-16 mx-auto border-4 border-yellow-400 relative">
              <div className="w-full h-full bg-red-600 relative">
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="text-yellow-400 text-3xl">★</div>
                </div>
              </div>
            </div>
          </div>
          
          <CardTitle className="text-4xl font-bold text-red-600 mb-2">
            Mario Bộ Đội vs Cali
          </CardTitle>
          
          <p className="text-lg text-gray-700 mb-4">
            Kỷ niệm 80 năm Quốc khánh Việt Nam
          </p>
          
          <div className="text-yellow-600 font-bold text-xl">
            2/9/1945 - 2/9/2025
          </div>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="text-center text-gray-700 space-y-3">
            <p className="text-lg">
              Hóa thân thành anh bộ đội Việt Nam dũng cảm!
            </p>
            <p>
              Vượt qua chướng ngại vật và đánh bại đám quái Cali giả dạng
            </p>
            <p>
              Nhặt cờ đỏ sao vàng, bánh chưng và ngôi sao để chiến thắng!
            </p>
          </div>
          
          <div className="bg-gray-100 p-4 rounded-lg">
            <h3 className="font-bold text-lg mb-3 text-center">Hướng dẫn chơi:</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <div className="font-semibold">Di chuyển:</div>
                <div>← → hoặc A D</div>
              </div>
              <div>
                <div className="font-semibold">Nhảy:</div>
                <div>↑ hoặc W hoặc Space</div>
              </div>
              <div>
                <div className="font-semibold">Tấn công:</div>
                <div>Ctrl</div>
              </div>
              <div>
                <div className="font-semibold">Mục tiêu:</div>
                <div>Đến cột cờ cuối màn</div>
              </div>
            </div>
          </div>
          
          <div className="bg-blue-50 p-4 rounded-lg">
            <h3 className="font-bold text-lg mb-3 text-center">Vật phẩm:</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-center">
              <div>
                <div className="text-2xl mb-1">🚩</div>
                <div className="font-semibold">Cờ đỏ sao vàng</div>
                <div>+100 điểm</div>
              </div>
              <div>
                <div className="text-2xl mb-1">🟫</div>
                <div className="font-semibold">Bánh chưng</div>
                <div>Hồi máu</div>
              </div>
              <div>
                <div className="text-2xl mb-1">⭐</div>
                <div className="font-semibold">Ngôi sao vàng</div>
                <div>Bất tử tạm thời</div>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              onClick={handleStartGame}
              size="lg"
              className="bg-red-600 hover:bg-red-700 text-white font-bold px-8 py-3 text-lg"
            >
              <Play className="w-5 h-5 mr-2" />
              Bắt đầu chiến đấu!
            </Button>
            
            <Button
              onClick={toggleMute}
              variant="outline"
              size="lg"
              className="border-gray-400 hover:bg-gray-100"
            >
              {isMuted ? <VolumeX className="w-5 h-5 mr-2" /> : <Volume2 className="w-5 h-5 mr-2" />}
              {isMuted ? 'Bật âm thanh' : 'Tắt âm thanh'}
            </Button>
          </div>
          
          <div className="text-center text-sm text-gray-600">
            <p>Chúc mừng ngày Quốc khánh Việt Nam!</p>
            <p className="font-bold text-red-600">Tổ quốc ghi công!</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StartScreen;
