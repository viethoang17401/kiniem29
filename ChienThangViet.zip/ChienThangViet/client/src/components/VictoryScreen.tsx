import React, { useEffect, useState } from 'react';
import { useGameState } from '../lib/stores/useGameState';
import { useAudio } from '../lib/stores/useAudio';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Trophy, Home, Star, Flag } from 'lucide-react';

const VictoryScreen: React.FC = () => {
  const { setGameState, resetGame, score } = useGameState();
  const { backgroundMusic, playSuccess } = useAudio();
  const [showFireworks, setShowFireworks] = useState(false);

  useEffect(() => {
    // Play victory sound
    playSuccess();
    
    // Show fireworks after a delay
    const timer = setTimeout(() => {
      setShowFireworks(true);
    }, 1000);
    
    // Stop background music
    if (backgroundMusic) {
      backgroundMusic.pause();
    }

    return () => clearTimeout(timer);
  }, [playSuccess, backgroundMusic]);

  const handlePlayAgain = () => {
    resetGame();
    setGameState('playing');
    
    // Restart background music
    if (backgroundMusic) {
      backgroundMusic.currentTime = 0;
      backgroundMusic.play().catch(error => {
        console.log('Background music play prevented:', error);
      });
    }
  };

  const handleBackToMenu = () => {
    resetGame();
    setGameState('menu');
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-b from-yellow-400 via-red-500 to-red-600 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0">
        {showFireworks && (
          <>
            {/* Firework particles */}
            {Array.from({ length: 20 }, (_, i) => (
              <div
                key={i}
                className="absolute w-2 h-2 bg-yellow-300 rounded-full animate-ping"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  animationDelay: `${Math.random() * 2}s`,
                  animationDuration: `${1 + Math.random()}s`
                }}
              />
            ))}
            {Array.from({ length: 15 }, (_, i) => (
              <div
                key={`star-${i}`}
                className="absolute text-yellow-300 text-2xl animate-bounce"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  animationDelay: `${Math.random() * 3}s`
                }}
              >
                ⭐
              </div>
            ))}
          </>
        )}
      </div>
      
      <div className="absolute inset-0 bg-black bg-opacity-20"></div>
      
      <Card className="w-full max-w-2xl mx-4 bg-white bg-opacity-95 shadow-2xl z-10 relative">
        <CardHeader className="text-center pb-6">
          <div className="mb-4">
            {/* Victory Trophy with Vietnamese Flag */}
            <div className="relative mx-auto w-24 h-24">
              <Trophy className="w-24 h-24 text-yellow-500 mx-auto" />
              <div className="absolute top-2 left-1/2 transform -translate-x-1/2 w-12 h-8 border-2 border-yellow-400">
                <div className="w-full h-full bg-red-600 relative">
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    <div className="text-yellow-400 text-lg">★</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <CardTitle className="text-4xl font-bold text-red-600 mb-4 animate-pulse">
            CHIẾN THẮNG!
          </CardTitle>
          
          <div className="text-2xl font-bold text-yellow-600 mb-2">
            Chúc mừng 80 năm Quốc khánh 2/9
          </div>
          
          <div className="text-lg text-gray-700">
            1945 - 2025
          </div>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="text-center">
            <div className="bg-gradient-to-r from-red-100 to-yellow-100 p-6 rounded-lg mb-6 border-2 border-yellow-400">
              <div className="text-3xl font-bold text-red-600 mb-4">
                🎉 BỘ ĐỘI VIỆT NAM VÔ ĐỊCH! 🎉
              </div>
              <div className="text-lg text-gray-700 mb-4">
                Anh bộ đội đã hoàn thành xuất sắc nhiệm vụ bảo vệ Tổ quốc!
              </div>
              <div className="text-2xl font-bold text-blue-600">
                Tổng điểm: {score.toLocaleString()}
              </div>
            </div>
            
            <div className="bg-red-50 p-4 rounded-lg mb-4 border-l-4 border-red-600">
              <div className="text-xl font-bold text-red-600 mb-2">
                "Không có gì quý hơn độc lập tự do"
              </div>
              <div className="text-sm text-gray-600">
                - Chủ tịch Hồ Chí Minh
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-yellow-50 p-4 rounded-lg">
                <Flag className="w-8 h-8 text-red-600 mx-auto mb-2" />
                <div className="font-bold text-red-600">Cờ Tổ quốc</div>
                <div className="text-sm text-gray-600">Tung bay chiến thắng</div>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <Star className="w-8 h-8 text-yellow-600 mx-auto mb-2" />
                <div className="font-bold text-yellow-600">Anh hùng</div>
                <div className="text-sm text-gray-600">Dân tộc Việt Nam</div>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg">
                <Trophy className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <div className="font-bold text-blue-600">Vinh quang</div>
                <div className="text-sm text-gray-600">Muôn đời bất diệt</div>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={handlePlayAgain}
              size="lg"
              className="bg-green-600 hover:bg-green-700 text-white font-bold px-6 py-3"
            >
              <Star className="w-5 h-5 mr-2" />
              Chiến đấu lại
            </Button>
            
            <Button
              onClick={handleBackToMenu}
              variant="outline"
              size="lg"
              className="border-red-400 text-red-600 hover:bg-red-50 px-6 py-3"
            >
              <Home className="w-5 h-5 mr-2" />
              Về trang chủ
            </Button>
          </div>
          
          <div className="text-center text-sm text-gray-600 bg-gray-50 p-4 rounded-lg">
            <div className="font-bold text-red-600 mb-2">
              🇻🇳 VIỆT NAM MUÔN NĂM! 🇻🇳
            </div>
            <p>Cảm ơn bạn đã tham gia kỷ niệm 80 năm Quốc khánh Việt Nam!</p>
            <p>Chúc Tổ quốc ngày càng phồn vinh, hạnh phúc!</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default VictoryScreen;
