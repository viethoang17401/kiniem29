import { Physics } from './Physics';
import { Player } from './Player';

interface Projectile {
  x: number;
  y: number;
  width: number;
  height: number;
  velocityX: number;
  velocityY: number;
}

export class Boss {
  x: number;
  y: number;
  width: number = 80;
  height: number = 120;
  health: number = 10;
  maxHealth: number = 10;
  isAlive: boolean = true;
  velocityX: number = 0;
  velocityY: number = 0;
  
  // AI properties
  moveDirection: number = -1;
  moveTimer: number = 0;
  attackTimer: number = 0;
  attackCooldown: number = 2000; // 2 seconds
  
  // Animation
  animationFrame: number = 0;
  animationTimer: number = 0;
  
  // Projectiles
  projectiles: Projectile[] = [];

  constructor(x: number, y: number) {
    this.x = x;
    this.y = y;
  }

  update(player: Player, deltaTime: number): void {
    if (!this.isAlive) return;

    // Apply gravity
    Physics.applyGravity(this);
    
    // Simple AI movement
    this.moveTimer += deltaTime;
    if (this.moveTimer > 3000) { // Change direction every 3 seconds
      this.moveDirection *= -1;
      this.moveTimer = 0;
    }
    
    this.velocityX = this.moveDirection * 1;
    
    // Update position
    this.x += this.velocityX;
    this.y += this.velocityY;
    
    // Keep boss in bounds
    if (this.x < 100) {
      this.x = 100;
      this.moveDirection = 1;
    }
    if (this.x > 620) {
      this.x = 620;
      this.moveDirection = -1;
    }
    
    // Ground collision
    if (this.y > 380) {
      this.y = 380;
      this.velocityY = 0;
    }
    
    // Attack timer
    this.attackTimer += deltaTime;
    if (this.attackTimer > this.attackCooldown) {
      this.attack(player);
      this.attackTimer = 0;
    }
    
    // Update projectiles
    this.updateProjectiles(deltaTime);
    
    // Update animation
    this.updateAnimation(deltaTime);
  }

  private attack(player: Player): void {
    // Create projectile aimed at player
    const projectile: Projectile = {
      x: this.x + this.width / 2,
      y: this.y + this.height / 2,
      width: 16,
      height: 16,
      velocityX: 0,
      velocityY: 0
    };
    
    // Calculate direction to player
    const direction = Physics.getDirection(this, player);
    const speed = 4;
    
    projectile.velocityX = direction.x * speed;
    projectile.velocityY = direction.y * speed;
    
    this.projectiles.push(projectile);
  }

  private updateProjectiles(deltaTime: number): void {
    this.projectiles = this.projectiles.filter(projectile => {
      // Update position
      projectile.x += projectile.velocityX;
      projectile.y += projectile.velocityY;
      
      // Apply gravity to projectiles
      projectile.velocityY += 0.2;
      
      // Remove projectiles that go off screen or hit ground
      return projectile.x > -50 && projectile.x < 850 && projectile.y < 600;
    });
  }

  private updateAnimation(deltaTime: number): void {
    this.animationTimer += deltaTime;
    if (this.animationTimer > 500) { // 500ms per frame
      this.animationFrame = (this.animationFrame + 1) % 2;
      this.animationTimer = 0;
    }
  }

  render(ctx: CanvasRenderingContext2D): void {
    if (!this.isAlive) return;

    ctx.save();
    
    // Draw large Cali boss
    // Main body (dark brown)
    ctx.fillStyle = '#654321';
    ctx.fillRect(this.x, this.y + 40, this.width, this.height - 40);
    
    // Head (larger)
    ctx.fillStyle = '#8B4513';
    ctx.fillRect(this.x + 10, this.y, this.width - 20, 50);
    
    // Evil eyes (red and glowing)
    ctx.fillStyle = '#FF0000';
    ctx.fillRect(this.x + 20, this.y + 15, 8, 8);
    ctx.fillRect(this.x + 52, this.y + 15, 8, 8);
    
    // Evil grin
    ctx.fillStyle = '#000000';
    ctx.fillRect(this.x + 25, this.y + 30, 30, 4);
    
    // Arms (throwing position)
    ctx.fillStyle = '#654321';
    ctx.fillRect(this.x - 15, this.y + 50, 20, 30);
    ctx.fillRect(this.x + this.width - 5, this.y + 50, 20, 30);
    
    // Legs
    ctx.fillStyle = '#654321';
    ctx.fillRect(this.x + 15, this.y + 100, 15, 25);
    ctx.fillRect(this.x + 50, this.y + 100, 15, 25);
    
    // Health bar
    this.renderHealthBar(ctx);
    
    // Render projectiles (rocks)
    this.renderProjectiles(ctx);
    
    ctx.restore();
  }

  private renderHealthBar(ctx: CanvasRenderingContext2D): void {
    const barWidth = 80;
    const barHeight = 8;
    const barX = this.x;
    const barY = this.y - 20;
    
    // Background
    ctx.fillStyle = '#FF0000';
    ctx.fillRect(barX, barY, barWidth, barHeight);
    
    // Health
    const healthPercent = this.health / this.maxHealth;
    ctx.fillStyle = '#00FF00';
    ctx.fillRect(barX, barY, barWidth * healthPercent, barHeight);
    
    // Border
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 2;
    ctx.strokeRect(barX, barY, barWidth, barHeight);
  }

  private renderProjectiles(ctx: CanvasRenderingContext2D): void {
    ctx.fillStyle = '#8B4513'; // Brown rocks
    this.projectiles.forEach(projectile => {
      // Draw rock with some texture
      ctx.fillRect(projectile.x, projectile.y, projectile.width, projectile.height);
      
      // Add some shading
      ctx.fillStyle = '#654321';
      ctx.fillRect(projectile.x, projectile.y, projectile.width / 2, projectile.height / 2);
      ctx.fillStyle = '#8B4513';
    });
  }

  takeDamage(amount: number): boolean {
    this.health -= amount;
    if (this.health <= 0) {
      this.isAlive = false;
      return true; // Boss defeated
    }
    return false;
  }

  getBounds() {
    return {
      x: this.x,
      y: this.y,
      width: this.width,
      height: this.height
    };
  }
}
