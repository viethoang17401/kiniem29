export type CollectibleType = 'flag' | 'banhchung' | 'star' | 'weaponUpgrade';

export class Collectible {
  x: number;
  y: number;
  width: number = 24;
  height: number = 24;
  type: CollectibleType;
  isCollected: boolean = false;
  animationOffset: number = 0;
  animationSpeed: number = 0.1;
  value: number;

  constructor(x: number, y: number, type: CollectibleType) {
    this.x = x;
    this.y = y;
    this.type = type;
    this.animationOffset = Math.random() * Math.PI * 2;
    
    // Set values based on type
    switch (type) {
      case 'flag':
        this.value = 100;
        this.width = 32;
        this.height = 40;
        break;
      case 'banhchung':
        this.value = 0; // Health item
        this.width = 28;
        this.height = 28;
        break;
      case 'star':
        this.value = 500;
        this.width = 24;
        this.height = 24;
        break;
      case 'weaponUpgrade':
        this.value = 0; // Special item
        this.width = 32;
        this.height = 20;
        break;
    }
  }

  update(deltaTime: number): void {
    if (this.isCollected) return;

    // Floating animation
    this.animationOffset += this.animationSpeed * deltaTime / 16;
    
    // Rotation for star
    if (this.type === 'star') {
      this.animationOffset += 0.05;
    }
  }

  render(ctx: CanvasRenderingContext2D): void {
    if (this.isCollected) return;

    ctx.save();

    const floatY = this.y + Math.sin(this.animationOffset) * 3;

    switch (this.type) {
      case 'flag':
        this.renderFlag(ctx, floatY);
        break;
      case 'banhchung':
        this.renderBanhChung(ctx, floatY);
        break;
      case 'star':
        this.renderStar(ctx, floatY);
        break;
      case 'weaponUpgrade':
        this.renderWeaponUpgrade(ctx, floatY);
        break;
    }

    ctx.restore();
  }

  private renderFlag(ctx: CanvasRenderingContext2D, y: number): void {
    // Flag pole
    ctx.fillStyle = '#8B4513';
    ctx.fillRect(this.x, y, 4, this.height);
    
    // Flag (red with yellow star)
    ctx.fillStyle = '#FF0000';
    ctx.fillRect(this.x + 4, y, 24, 16);
    
    // Yellow star
    ctx.fillStyle = '#FFD700';
    ctx.beginPath();
    const starX = this.x + 16;
    const starY = y + 8;
    for (let i = 0; i < 5; i++) {
      const angle = (i * 144 - 90) * Math.PI / 180;
      const x = starX + Math.cos(angle) * 4;
      const sy = starY + Math.sin(angle) * 4;
      if (i === 0) ctx.moveTo(x, sy);
      else ctx.lineTo(x, sy);
    }
    ctx.closePath();
    ctx.fill();
  }

  private renderBanhChung(ctx: CanvasRenderingContext2D, y: number): void {
    // Bánh chưng (square green cake wrapped in banana leaves)
    
    // Banana leaf wrapping (green)
    ctx.fillStyle = '#228B22';
    ctx.fillRect(this.x - 2, y - 2, this.width + 4, this.height + 4);
    
    // Main cake (lighter green)
    ctx.fillStyle = '#90EE90';
    ctx.fillRect(this.x + 2, y + 2, this.width - 4, this.height - 4);
    
    // Mung bean filling (yellow center)
    ctx.fillStyle = '#FFD700';
    ctx.fillRect(this.x + 8, y + 8, this.width - 16, this.height - 16);
    
    // Binding strings (brown)
    ctx.strokeStyle = '#8B4513';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(this.x, y + this.height / 2);
    ctx.lineTo(this.x + this.width, y + this.height / 2);
    ctx.moveTo(this.x + this.width / 2, y);
    ctx.lineTo(this.x + this.width / 2, y + this.height);
    ctx.stroke();
  }

  private renderStar(ctx: CanvasRenderingContext2D, y: number): void {
    ctx.save();
    
    // Rotate the star
    ctx.translate(this.x + this.width / 2, y + this.height / 2);
    ctx.rotate(this.animationOffset);
    
    // Golden star with glow effect
    ctx.shadowColor = '#FFD700';
    ctx.shadowBlur = 10;
    ctx.fillStyle = '#FFD700';
    
    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
      const angle = (i * 144 - 90) * Math.PI / 180;
      const x = Math.cos(angle) * 10;
      const sy = Math.sin(angle) * 10;
      if (i === 0) ctx.moveTo(x, sy);
      else ctx.lineTo(x, sy);
    }
    ctx.closePath();
    ctx.fill();
    
    ctx.restore();
  }
  
  private renderWeaponUpgrade(ctx: CanvasRenderingContext2D, y: number): void {
    // Special weapon upgrade item - golden rifle
    
    // Base rifle shape
    ctx.fillStyle = '#DAA520';
    ctx.fillRect(this.x, y + 8, 28, 4);
    
    // Rifle stock
    ctx.fillStyle = '#B8860B';
    ctx.fillRect(this.x + 20, y + 6, 8, 8);
    
    // Scope
    ctx.fillStyle = '#2F4F4F';
    ctx.fillRect(this.x + 8, y + 6, 8, 2);
    
    // Glow effect
    const glowTime = Date.now() * 0.005;
    const glow = 0.5 + 0.5 * Math.sin(glowTime);
    ctx.shadowColor = '#FFD700';
    ctx.shadowBlur = 5 + glow * 3;
    
    // Golden outline
    ctx.strokeStyle = '#FFD700';
    ctx.lineWidth = 2;
    ctx.strokeRect(this.x - 1, y + 7, 30, 6);
    
    ctx.shadowBlur = 0;
    
    // Floating golden particles
    for (let i = 0; i < 3; i++) {
      const particleX = this.x + 10 + Math.sin(glowTime + i * 2) * 8;
      const particleY = y + 5 + Math.cos(glowTime + i * 1.5) * 3;
      ctx.fillStyle = `rgba(255, 215, 0, ${0.7 + Math.sin(glowTime + i) * 0.3})`;
      ctx.beginPath();
      ctx.arc(particleX, particleY, 1, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  collect(): { type: CollectibleType; value: number } {
    this.isCollected = true;
    return { type: this.type, value: this.value };
  }

  getBounds() {
    return {
      x: this.x,
      y: this.y,
      width: this.width,
      height: this.height
    };
  }
}
