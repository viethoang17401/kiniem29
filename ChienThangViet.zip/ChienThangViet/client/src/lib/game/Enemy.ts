import { Physics } from './Physics';

export type EnemyType = 'goomba' | 'koopa';

export class Enemy {
  x: number;
  y: number;
  width: number = 32;
  height: number = 32;
  velocityX: number = -1;
  velocityY: number = 0;
  type: EnemyType;
  isAlive: boolean = true;
  health: number = 1;
  direction: 'left' | 'right' = 'left';
  patrolStartX: number;
  patrolEndX: number;
  animationFrame: number = 0;
  animationTimer: number = 0;

  constructor(x: number, y: number, type: EnemyType = 'goomba') {
    this.x = x;
    this.y = y;
    this.type = type;
    this.patrolStartX = x - 100;
    this.patrolEndX = x + 100;
    
    if (type === 'koopa') {
      this.width = 36;
      this.height = 40;
      this.health = 2;
    }
  }

  update(platforms: any[], deltaTime: number): void {
    if (!this.isAlive) return;

    // Apply gravity
    Physics.applyGravity(this);
    
    // AI movement - simple patrol
    if (this.x <= this.patrolStartX) {
      this.velocityX = Math.abs(this.velocityX);
      this.direction = 'right';
    } else if (this.x >= this.patrolEndX) {
      this.velocityX = -Math.abs(this.velocityX);
      this.direction = 'left';
    }

    // Update position
    this.x += this.velocityX;
    this.y += this.velocityY;

    // Platform collision
    for (const platform of platforms) {
      if (Physics.checkCollision(this, platform)) {
        if (this.velocityY > 0 && this.y < platform.y) {
          this.y = platform.y - this.height;
          this.velocityY = 0;
        }
      }
    }

    // Ground collision
    if (this.y > 518) {
      this.y = 518;
      this.velocityY = 0;
    }

    // Update animation
    this.updateAnimation(deltaTime);
  }

  private updateAnimation(deltaTime: number): void {
    this.animationTimer += deltaTime;
    if (this.animationTimer > 300) { // 300ms per frame
      this.animationFrame = (this.animationFrame + 1) % 2;
      this.animationTimer = 0;
    }
  }

  render(ctx: CanvasRenderingContext2D): void {
    if (!this.isAlive) return;

    ctx.save();

    if (this.type === 'goomba') {
      // Draw enhanced Cali Goomba - more detailed and humorous but menacing
      
      // Body (gradient brown for depth)
      const gradient = ctx.createLinearGradient(this.x, this.y, this.x, this.y + this.height);
      gradient.addColorStop(0, '#A0522D');
      gradient.addColorStop(1, '#654321');
      ctx.fillStyle = gradient;
      ctx.fillRect(this.x + 2, this.y + 16, this.width - 4, this.height - 16);
      
      // Body outline for cartoon effect
      ctx.strokeStyle = '#2F1B14';
      ctx.lineWidth = 2;
      ctx.strokeRect(this.x + 2, this.y + 16, this.width - 4, this.height - 16);
      
      // Conical hat (Vietnamese nón lá) with better shading
      ctx.fillStyle = '#F5DEB3';
      ctx.beginPath();
      ctx.ellipse(this.x + this.width/2, this.y + 8, this.width/2 + 5, 14, 0, 0, 2 * Math.PI);
      ctx.fill();
      
      // Hat shadow
      ctx.fillStyle = '#DEB887';
      ctx.beginPath();
      ctx.ellipse(this.x + this.width/2, this.y + 10, this.width/2 + 3, 10, 0, 0, 2 * Math.PI);
      ctx.fill();
      
      // Hat brim with depth
      ctx.fillStyle = '#D2B48C';
      ctx.beginPath();
      ctx.ellipse(this.x + this.width/2, this.y + 14, this.width/2 + 7, 5, 0, 0, 2 * Math.PI);
      ctx.fill();
      
      // Face (more expressive)
      ctx.fillStyle = '#8B4513';
      ctx.fillRect(this.x + 6, this.y + 12, this.width - 12, 14);
      
      // Eyes (animated and menacing)
      const eyeGlow = Math.sin(Date.now() * 0.01) * 0.3 + 0.7;
      ctx.fillStyle = `rgba(255, 0, 0, ${eyeGlow})`;
      ctx.fillRect(this.x + 9, this.y + 14, 4, 4);
      ctx.fillRect(this.x + 19, this.y + 14, 4, 4);
      
      // Eye pupils
      ctx.fillStyle = '#000000';
      ctx.fillRect(this.x + 10, this.y + 15, 2, 2);
      ctx.fillRect(this.x + 20, this.y + 15, 2, 2);
      
      // Angry eyebrows
      ctx.fillStyle = '#2F1B14';
      ctx.fillRect(this.x + 8, this.y + 12, 6, 2);
      ctx.fillRect(this.x + 18, this.y + 12, 6, 2);
      
      // Menacing mouth (gritted teeth)
      ctx.fillStyle = '#000000';
      ctx.fillRect(this.x + 11, this.y + 20, 10, 3);
      
      // Teeth lines
      ctx.fillStyle = '#FFFFFF';
      for (let i = 0; i < 3; i++) {
        ctx.fillRect(this.x + 12 + i * 3, this.y + 20, 1, 3);
      }
      
    } else if (this.type === 'koopa') {
      // Draw enhanced Cali Koopa - more detailed with Vietnamese military elements
      
      // Shell (green gradient with more detail)
      const shellGradient = ctx.createRadialGradient(
        this.x + this.width/2, this.y + this.height/2, 0,
        this.x + this.width/2, this.y + this.height/2, this.width/2
      );
      shellGradient.addColorStop(0, '#32CD32');
      shellGradient.addColorStop(1, '#228B22');
      ctx.fillStyle = shellGradient;
      ctx.beginPath();
      ctx.ellipse(this.x + this.width/2, this.y + this.height/2, this.width/2, this.height/2, 0, 0, 2 * Math.PI);
      ctx.fill();
      
      // Shell outline
      ctx.strokeStyle = '#006400';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.ellipse(this.x + this.width/2, this.y + this.height/2, this.width/2, this.height/2, 0, 0, 2 * Math.PI);
      ctx.stroke();
      
      // Red star on shell (animated)
      const starTime = Date.now() * 0.005;
      const starGlow = 0.7 + 0.3 * Math.sin(starTime);
      ctx.shadowColor = '#FF0000';
      ctx.shadowBlur = 5;
      ctx.fillStyle = `rgba(255, 0, 0, ${starGlow})`;
      ctx.beginPath();
      const starX = this.x + this.width/2;
      const starY = this.y + this.height/2;
      for (let i = 0; i < 5; i++) {
        const angle = (i * 144 - 90) * Math.PI / 180;
        const x = starX + Math.cos(angle) * 7;
        const y = starY + Math.sin(angle) * 7;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.fill();
      ctx.shadowBlur = 0;
      
      // Head (more expressive)
      ctx.fillStyle = '#FDBCB4';
      ctx.fillRect(this.x + 10, this.y - 10, 16, 18);
      
      // Head outline
      ctx.strokeStyle = '#CD853F';
      ctx.lineWidth = 1;
      ctx.strokeRect(this.x + 10, this.y - 10, 16, 18);
      
      // Vietnamese conical hat on head (more detailed)
      ctx.fillStyle = '#F5DEB3';
      ctx.beginPath();
      ctx.ellipse(this.x + this.width/2, this.y - 6, 10, 7, 0, 0, 2 * Math.PI);
      ctx.fill();
      
      // Hat lines
      ctx.strokeStyle = '#DEB887';
      ctx.lineWidth = 1;
      for (let i = 0; i < 3; i++) {
        ctx.beginPath();
        ctx.ellipse(this.x + this.width/2, this.y - 6 + i * 2, 8 - i, 5 - i, 0, 0, 2 * Math.PI);
        ctx.stroke();
      }
      
      // Evil eyes
      ctx.fillStyle = '#FF4500';
      ctx.fillRect(this.x + 12, this.y - 6, 3, 3);
      ctx.fillRect(this.x + 21, this.y - 6, 3, 3);
      
      // Eye pupils
      ctx.fillStyle = '#000000';
      ctx.fillRect(this.x + 13, this.y - 5, 1, 1);
      ctx.fillRect(this.x + 22, this.y - 5, 1, 1);
      
      // Menacing mouth
      ctx.fillStyle = '#000000';
      ctx.fillRect(this.x + 14, this.y - 2, 8, 2);
      
      // Legs (more muscular)
      ctx.fillStyle = '#FDBCB4';
      ctx.fillRect(this.x + 6, this.y + 32, 8, 10);
      ctx.fillRect(this.x + 22, this.y + 32, 8, 10);
      
      // Leg outlines
      ctx.strokeStyle = '#CD853F';
      ctx.lineWidth = 1;
      ctx.strokeRect(this.x + 6, this.y + 32, 8, 10);
      ctx.strokeRect(this.x + 22, this.y + 32, 8, 10);
    }

    ctx.restore();
  }

  takeDamage(amount: number = 1): boolean {
    this.health -= amount;
    if (this.health <= 0) {
      this.isAlive = false;
      return true; // Enemy defeated
    }
    return false;
  }

  getBounds() {
    return {
      x: this.x,
      y: this.y,
      width: this.width,
      height: this.height
    };
  }
}
