interface Particle {
  x: number;
  y: number;
  velocityX: number;
  velocityY: number;
  color: string;
  life: number;
  maxLife: number;
  size: number;
}

interface Firework {
  x: number;
  y: number;
  targetY: number;
  velocityY: number;
  exploded: boolean;
  particles: Particle[];
  color: string;
}

export class Fireworks {
  fireworks: Firework[] = [];
  lastFireworkTime: number = 0;
  colors: string[] = ['#FF0000', '#FFD700', '#00FF00', '#0080FF', '#FF69B4', '#FFA500', '#DC143C', '#FF4500'];
  burstCount: number = 0;

  update(deltaTime: number): void {
    // Create multiple fireworks for celebration
    if (Date.now() - this.lastFireworkTime > 500) { // Every 0.5 seconds
      // Create multiple fireworks at once for grand effect
      this.createFirework();
      if (Math.random() < 0.7) {
        setTimeout(() => this.createFirework(), 100);
      }
      if (Math.random() < 0.5) {
        setTimeout(() => this.createFirework(), 200);
      }
      this.lastFireworkTime = Date.now();
      this.burstCount++;
    }

    // Update existing fireworks
    this.fireworks = this.fireworks.filter(firework => {
      if (!firework.exploded) {
        // Move firework up
        firework.y += firework.velocityY;
        
        // Check if reached target height
        if (firework.y <= firework.targetY) {
          this.explodeFirework(firework);
        }
        
        return true;
      } else {
        // Update particles
        firework.particles = firework.particles.filter(particle => {
          particle.x += particle.velocityX;
          particle.y += particle.velocityY;
          particle.velocityY += 0.1; // Gravity
          particle.life -= deltaTime;
          
          return particle.life > 0;
        });
        
        // Remove firework if no particles left
        return firework.particles.length > 0;
      }
    });
  }

  private createFirework(): void {
    const firework: Firework = {
      x: 200 + Math.random() * 400, // More centered
      y: 600,
      targetY: 150 + Math.random() * 250,
      velocityY: -6 - Math.random() * 4, // Faster
      exploded: false,
      particles: [],
      color: this.colors[Math.floor(Math.random() * this.colors.length)]
    };
    
    this.fireworks.push(firework);
  }

  private explodeFirework(firework: Firework): void {
    firework.exploded = true;
    
    // Create more particles for grander effect
    const particleCount = 30 + Math.random() * 30;
    for (let i = 0; i < particleCount; i++) {
      const angle = (Math.PI * 2 * i) / particleCount;
      const speed = 3 + Math.random() * 5;
      
      const particle: Particle = {
        x: firework.x,
        y: firework.y,
        velocityX: Math.cos(angle) * speed,
        velocityY: Math.sin(angle) * speed,
        color: firework.color,
        life: 2500 + Math.random() * 1500, // Longer lasting
        maxLife: 4000,
        size: 3 + Math.random() * 4 // Larger particles
      };
      
      firework.particles.push(particle);
    }
    
    // Add some extra sparkle particles
    for (let i = 0; i < 10; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 1 + Math.random() * 2;
      
      const sparkle: Particle = {
        x: firework.x,
        y: firework.y,
        velocityX: Math.cos(angle) * speed,
        velocityY: Math.sin(angle) * speed,
        color: '#FFD700', // Gold sparkles
        life: 3000 + Math.random() * 2000,
        maxLife: 5000,
        size: 1 + Math.random() * 2
      };
      
      firework.particles.push(sparkle);
    }
  }

  render(ctx: CanvasRenderingContext2D): void {
    ctx.save();
    
    this.fireworks.forEach(firework => {
      if (!firework.exploded) {
        // Draw ascending firework
        ctx.fillStyle = firework.color;
        ctx.beginPath();
        ctx.arc(firework.x, firework.y, 3, 0, Math.PI * 2);
        ctx.fill();
        
        // Trail effect
        ctx.fillStyle = firework.color + '80'; // Semi-transparent
        ctx.beginPath();
        ctx.arc(firework.x, firework.y + 10, 2, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // Draw particles
        firework.particles.forEach(particle => {
          const alpha = particle.life / particle.maxLife;
          ctx.fillStyle = particle.color + Math.floor(alpha * 255).toString(16).padStart(2, '0');
          ctx.beginPath();
          ctx.arc(particle.x, particle.y, particle.size * alpha, 0, Math.PI * 2);
          ctx.fill();
        });
      }
    });
    
    ctx.restore();
  }
}
