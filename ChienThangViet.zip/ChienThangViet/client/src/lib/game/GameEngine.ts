import { Player } from './Player';
import { Level } from './Level';
import { Boss } from './Boss';
import { Fireworks } from './Fireworks';
import { Physics } from './Physics';
import { useGameState } from '../stores/useGameState';
import { useAudio } from '../stores/useAudio';

export class GameEngine {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  player: Player;
  currentLevel: number = 1;
  level: Level;
  boss: Boss | null = null;
  fireworks: Fireworks;
  keys: Set<string> = new Set();
  gameComplete: boolean = false;
  
  // Game timing
  lastTime: number = 0;
  deltaTime: number = 0;
  
  // Camera
  cameraX: number = 0;
  cameraY: number = 0;
  
  // Hit effects
  hitEffects: Array<{x: number, y: number, life: number, type: 'spark' | 'explosion'}> = [];

  constructor(width: number, height: number) {
    // Create a temporary canvas for initialization
    this.canvas = document.createElement('canvas');
    this.canvas.width = width;
    this.canvas.height = height;
    this.ctx = this.canvas.getContext('2d')!;
    
    // Initialize game objects
    this.player = new Player(50, 400);
    this.level = new Level(this.currentLevel);
    this.fireworks = new Fireworks();
    
    console.log('Game engine initialized');
  }

  handleKeyDown(key: string): void {
    this.keys.add(key.toLowerCase());
    
    // Attack key
    if (key.toLowerCase() === 'control' || key.toLowerCase() === 'ctrl') {
      this.handlePlayerAttack();
    }
  }

  handleKeyUp(key: string): void {
    this.keys.delete(key.toLowerCase());
  }

  handleMouseClick(x: number, y: number): void {
    // Convert screen coordinates to world coordinates
    const worldX = x + this.cameraX;
    const worldY = y + this.cameraY;
    
    if (this.player) {
      this.player.handleMouseClick(worldX, worldY);
    }
  }

  private handlePlayerAttack(): void {
    // Check for enemies in attack range
    const attackRange = 50;
    const playerBounds = this.player.getBounds();
    
    for (const enemy of this.level.enemies) {
      if (!enemy.isAlive) continue;
      
      const distance = Physics.distance(playerBounds, enemy.getBounds());
      if (distance < attackRange) {
        const defeated = enemy.takeDamage(1);
        if (defeated) {
          useGameState.getState().addScore(100);
          useAudio.getState().playHit();
          this.level.removeEnemy(enemy);
        }
      }
    }
    
    // Check boss attack
    if (this.boss && this.boss.isAlive) {
      const distance = Physics.distance(playerBounds, this.boss.getBounds());
      if (distance < attackRange) {
        const defeated = this.boss.takeDamage(1);
        if (defeated) {
          useGameState.getState().addScore(1000);
          useAudio.getState().playSuccess();
          this.gameComplete = true;
        } else {
          useAudio.getState().playHit();
        }
      }
    }
  }

  update(): void {
    const currentTime = Date.now();
    this.deltaTime = currentTime - this.lastTime;
    this.lastTime = currentTime;

    // Update player
    this.player.update(this.keys, this.level.platforms, this.deltaTime);
    
    // Update level
    this.level.update(this.deltaTime);
    
    // Update boss if exists
    if (this.boss) {
      this.boss.update(this.player, this.deltaTime);
    }
    
    // Check collisions
    this.checkCollisions();
    
    // Check bullet collisions
    this.checkBulletCollisions();
    
    // Check level completion
    if (this.level.checkGoalReached(this.player.x) && !this.level.isBossLevel) {
      this.nextLevel();
    }
    
    // Update camera to follow player
    this.updateCamera();
    
    // Update fireworks if game is complete
    if (this.gameComplete) {
      this.fireworks.update(this.deltaTime);
    }
    
    // Update hit effects
    this.hitEffects = this.hitEffects.filter(effect => {
      effect.life -= this.deltaTime;
      return effect.life > 0;
    });
  }

  private checkBulletCollisions(): void {
    const bullets = this.player.getBullets();
    
    for (let i = bullets.length - 1; i >= 0; i--) {
      const bullet = bullets[i];
      const bulletBounds = {
        x: bullet.x - 2,
        y: bullet.y - 2,
        width: 4,
        height: 4
      };
      
      // Check bullet vs enemies
      for (const enemy of this.level.enemies) {
        if (!enemy.isAlive) continue;
        
        if (Physics.checkCollision(bulletBounds, enemy.getBounds())) {
          const defeated = enemy.takeDamage(1);
          if (defeated) {
            useGameState.getState().addScore(150);
            useAudio.getState().playHit();
            this.level.removeEnemy(enemy);
            // Create explosion effect
            this.createHitEffect(enemy.x + enemy.width/2, enemy.y + enemy.height/2, 'explosion');
          } else {
            // Create spark effect
            this.createHitEffect(bullet.x, bullet.y, 'spark');
          }
          
          // Remove bullet unless it's upgraded (penetrating)
          if (!bullet.upgraded) {
            this.player.removeBullet(i);
            break;
          }
        }
      }
      
      // Check bullet vs boss
      if (this.boss && this.boss.isAlive) {
        if (Physics.checkCollision(bulletBounds, this.boss.getBounds())) {
          const defeated = this.boss.takeDamage(1);
          if (defeated) {
            useGameState.getState().addScore(1000);
            useAudio.getState().playSuccess();
            this.gameComplete = true;
            // Create big explosion effect
            this.createHitEffect(this.boss.x + this.boss.width/2, this.boss.y + this.boss.height/2, 'explosion');
          } else {
            useAudio.getState().playHit();
            // Create spark effect
            this.createHitEffect(bullet.x, bullet.y, 'spark');
          }
          
          // Remove bullet unless it's upgraded
          if (!bullet.upgraded) {
            this.player.removeBullet(i);
          }
        }
      }
    }
  }

  private checkCollisions(): void {
    const playerBounds = this.player.getBounds();
    
    // Check enemy collisions
    for (const enemy of this.level.enemies) {
      if (!enemy.isAlive) continue;
      
      if (Physics.checkCollision(playerBounds, enemy.getBounds())) {
        // Check if player is stomping enemy
        if (this.player.velocityY > 0 && playerBounds.y < enemy.y) {
          const defeated = enemy.takeDamage(1);
          if (defeated) {
            useGameState.getState().addScore(200);
            useAudio.getState().playHit();
            this.level.removeEnemy(enemy);
            this.player.velocityY = -8; // Bounce
          }
        } else {
          // Player takes damage
          this.player.takeDamage(1);
          useAudio.getState().playHit();
        }
      }
    }
    
    // Check collectible collisions
    for (const collectible of this.level.collectibles) {
      if (collectible.isCollected) continue;
      
      if (Physics.checkCollision(playerBounds, collectible.getBounds())) {
        const collected = collectible.collect();
        
        switch (collected.type) {
          case 'flag':
            useGameState.getState().addScore(collected.value);
            useAudio.getState().playSuccess();
            break;
          case 'banhchung':
            this.player.heal(1);
            useAudio.getState().playSuccess();
            break;
          case 'star':
            useGameState.getState().addScore(collected.value);
            this.player.makeInvincible(5000); // 5 seconds
            useAudio.getState().playSuccess();
            break;
          case 'weaponUpgrade':
            this.player.upgradeWeapon();
            useGameState.getState().addScore(200);
            useAudio.getState().playSuccess();
            break;
        }
        
        this.level.removeCollectible(collectible);
      }
    }
    
    // Check boss collisions
    if (this.boss && this.boss.isAlive) {
      if (Physics.checkCollision(playerBounds, this.boss.getBounds())) {
        this.player.takeDamage(1);
        useAudio.getState().playHit();
      }
      
      // Check boss projectile collisions
      for (const projectile of this.boss.projectiles) {
        if (Physics.checkCollision(playerBounds, projectile)) {
          this.player.takeDamage(1);
          useAudio.getState().playHit();
          // Remove projectile
          const index = this.boss.projectiles.indexOf(projectile);
          if (index > -1) {
            this.boss.projectiles.splice(index, 1);
          }
        }
      }
    }
  }

  private nextLevel(): void {
    this.currentLevel++;
    
    if (this.currentLevel <= 3) {
      // Regular levels
      this.level = new Level(this.currentLevel);
      this.player.x = 50;
      this.player.y = 400;
      useGameState.getState().addScore(500); // Level completion bonus
    } else {
      // Boss level
      this.level = new Level(4);
      this.boss = new Boss(600, 300);
      this.player.x = 50;
      this.player.y = 450;
    }
  }

  private updateCamera(): void {
    // Simple camera follow
    this.cameraX = this.player.x - 400; // Center player horizontally
    this.cameraY = Math.max(0, this.player.y - 300); // Keep camera above ground
    
    // Clamp camera
    this.cameraX = Math.max(0, Math.min(this.cameraX, 200));
    this.cameraY = Math.max(0, this.cameraY);
  }

  render(ctx: CanvasRenderingContext2D): void {
    // Clear canvas
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    
    // Save context for camera transform
    ctx.save();
    ctx.translate(-this.cameraX, -this.cameraY);
    
    // Render level
    this.level.render(ctx);
    
    // Render boss
    if (this.boss) {
      this.boss.render(ctx);
    }
    
    // Render player
    this.player.render(ctx);
    
    // Restore context
    ctx.restore();
    
    // Render hit effects (world space)
    this.renderHitEffects(ctx);
    
    // Render fireworks (screen space)
    if (this.gameComplete) {
      this.fireworks.render(ctx);
      
      // Victory message
      ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
      ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);
      
      ctx.fillStyle = '#FFD700';
      ctx.font = 'bold 32px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('CHIẾN THẮNG!', ctx.canvas.width / 2, ctx.canvas.height / 2 - 50);
      
      ctx.fillStyle = '#FF0000';
      ctx.font = 'bold 24px Arial';
      ctx.fillText('Chúc mừng 80 năm Quốc khánh 2/9', ctx.canvas.width / 2, ctx.canvas.height / 2);
      
      ctx.fillStyle = '#FFFFFF';
      ctx.font = '18px Arial';
      ctx.fillText('Bộ đội Việt Nam vô địch!', ctx.canvas.width / 2, ctx.canvas.height / 2 + 40);
    }
  }
  
  private createHitEffect(x: number, y: number, type: 'spark' | 'explosion'): void {
    this.hitEffects.push({
      x: x,
      y: y,
      life: type === 'explosion' ? 500 : 300,
      type: type
    });
  }
  
  private renderHitEffects(ctx: CanvasRenderingContext2D): void {
    this.hitEffects.forEach(effect => {
      ctx.save();
      
      const lifeRatio = effect.life / (effect.type === 'explosion' ? 500 : 300);
      
      if (effect.type === 'explosion') {
        // Explosion effect - expanding circles
        const radius = (1 - lifeRatio) * 20;
        
        // Outer ring - orange
        ctx.fillStyle = `rgba(255, 69, 0, ${lifeRatio * 0.8})`;
        ctx.beginPath();
        ctx.arc(effect.x, effect.y, radius, 0, Math.PI * 2);
        ctx.fill();
        
        // Inner ring - yellow
        ctx.fillStyle = `rgba(255, 255, 0, ${lifeRatio})`;
        ctx.beginPath();
        ctx.arc(effect.x, effect.y, radius * 0.6, 0, Math.PI * 2);
        ctx.fill();
        
        // Core - white
        ctx.fillStyle = `rgba(255, 255, 255, ${lifeRatio})`;
        ctx.beginPath();
        ctx.arc(effect.x, effect.y, radius * 0.3, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // Spark effect - radiating lines
        ctx.strokeStyle = `rgba(255, 215, 0, ${lifeRatio})`;
        ctx.lineWidth = 2;
        
        for (let i = 0; i < 6; i++) {
          const angle = (i * Math.PI * 2) / 6;
          const length = (1 - lifeRatio) * 15;
          
          ctx.beginPath();
          ctx.moveTo(effect.x, effect.y);
          ctx.lineTo(
            effect.x + Math.cos(angle) * length,
            effect.y + Math.sin(angle) * length
          );
          ctx.stroke();
        }
      }
      
      ctx.restore();
    });
  }
}
