import { Enemy, EnemyType } from './Enemy';
import { Collectible, CollectibleType } from './Collectible';

export interface Platform {
  x: number;
  y: number;
  width: number;
  height: number;
}

export class Level {
  levelNumber: number;
  platforms: Platform[] = [];
  enemies: Enemy[] = [];
  collectibles: Collectible[] = [];
  playerStartX: number = 50;
  playerStartY: number = 400;
  goalX: number = 750;
  isComplete: boolean = false;
  isBossLevel: boolean = false;
  
  // Vietnamese flag animation
  flagWave: number = 0;

  constructor(levelNumber: number) {
    this.levelNumber = levelNumber;
    this.generateLevel();
    this.flagWave = 0;
  }

  private generateLevel(): void {
    // Clear existing entities
    this.platforms = [];
    this.enemies = [];
    this.collectibles = [];

    switch (this.levelNumber) {
      case 1:
        this.generateLevel1();
        break;
      case 2:
        this.generateLevel2();
        break;
      case 3:
        this.generateLevel3();
        break;
      default:
        this.generateBossLevel();
        this.isBossLevel = true;
        break;
    }
  }

  private generateLevel1(): void {
    // Basic level with simple platforms
    this.platforms = [
      { x: 200, y: 500, width: 100, height: 20 },
      { x: 350, y: 450, width: 100, height: 20 },
      { x: 500, y: 400, width: 100, height: 20 },
      { x: 650, y: 350, width: 100, height: 20 }
    ];

    // Simple enemies
    this.enemies = [
      new Enemy(250, 450, 'goomba'),
      new Enemy(400, 350, 'goomba'),
      new Enemy(550, 300, 'koopa')
    ];

    // Collectibles
    this.collectibles = [
      new Collectible(220, 470, 'flag'),
      new Collectible(520, 370, 'banhchung'),
      new Collectible(670, 320, 'star'),
      new Collectible(300, 380, 'weaponUpgrade')
    ];
  }

  private generateLevel2(): void {
    // More complex level
    this.platforms = [
      { x: 150, y: 480, width: 80, height: 20 },
      { x: 280, y: 420, width: 80, height: 20 },
      { x: 200, y: 360, width: 120, height: 20 },
      { x: 400, y: 300, width: 100, height: 20 },
      { x: 550, y: 380, width: 80, height: 20 },
      { x: 680, y: 320, width: 100, height: 20 }
    ];

    // More enemies
    this.enemies = [
      new Enemy(170, 430, 'goomba'),
      new Enemy(300, 370, 'koopa'),
      new Enemy(240, 310, 'goomba'),
      new Enemy(570, 330, 'koopa'),
      new Enemy(700, 270, 'goomba')
    ];

    // More collectibles
    this.collectibles = [
      new Collectible(170, 450, 'flag'),
      new Collectible(420, 270, 'banhchung'),
      new Collectible(260, 330, 'flag'),
      new Collectible(590, 350, 'star'),
      new Collectible(720, 290, 'banhchung'),
      new Collectible(350, 370, 'weaponUpgrade')
    ];
  }

  private generateLevel3(): void {
    // Challenging level before boss
    this.platforms = [
      { x: 100, y: 500, width: 60, height: 20 },
      { x: 200, y: 450, width: 60, height: 20 },
      { x: 300, y: 400, width: 60, height: 20 },
      { x: 400, y: 350, width: 60, height: 20 },
      { x: 500, y: 300, width: 60, height: 20 },
      { x: 600, y: 250, width: 60, height: 20 },
      { x: 450, y: 200, width: 100, height: 20 },
      { x: 300, y: 150, width: 200, height: 20 }
    ];

    // Many enemies
    this.enemies = [
      new Enemy(120, 450, 'koopa'),
      new Enemy(220, 400, 'goomba'),
      new Enemy(320, 350, 'koopa'),
      new Enemy(420, 300, 'goomba'),
      new Enemy(520, 250, 'koopa'),
      new Enemy(480, 150, 'goomba'),
      new Enemy(380, 100, 'koopa')
    ];

    // Valuable collectibles
    this.collectibles = [
      new Collectible(130, 470, 'flag'),
      new Collectible(250, 420, 'banhchung'),
      new Collectible(350, 370, 'flag'),
      new Collectible(450, 320, 'star'),
      new Collectible(550, 270, 'banhchung'),
      new Collectible(500, 170, 'flag'),
      new Collectible(400, 120, 'star'),
      new Collectible(320, 340, 'weaponUpgrade')
    ];
  }

  private generateBossLevel(): void {
    // Simple platform for boss fight
    this.platforms = [
      { x: 100, y: 500, width: 600, height: 20 },
      { x: 150, y: 400, width: 100, height: 20 },
      { x: 550, y: 400, width: 100, height: 20 }
    ];

    // Health items for boss fight
    this.collectibles = [
      new Collectible(180, 370, 'banhchung'),
      new Collectible(580, 370, 'banhchung')
    ];

    // No regular enemies in boss level
  }

  update(deltaTime: number): void {
    // Update enemies
    this.enemies = this.enemies.filter(enemy => enemy.isAlive);
    this.enemies.forEach(enemy => enemy.update(this.platforms, deltaTime));

    // Update collectibles
    this.collectibles.forEach(collectible => collectible.update(deltaTime));
    
    // Update flag animation
    this.flagWave += deltaTime * 0.005;
  }

  render(ctx: CanvasRenderingContext2D): void {
    // Render platforms
    ctx.fillStyle = '#8B4513'; // Brown color for platforms
    this.platforms.forEach(platform => {
      ctx.fillRect(platform.x, platform.y, platform.width, platform.height);
      
      // Add some texture to platforms
      ctx.fillStyle = '#A0522D';
      ctx.fillRect(platform.x, platform.y, platform.width, 5);
      ctx.fillStyle = '#8B4513';
    });

    // Render enemies
    this.enemies.forEach(enemy => enemy.render(ctx));

    // Render collectibles
    this.collectibles.forEach(collectible => collectible.render(ctx));

    // Render goal flag at the end
    if (!this.isBossLevel) {
      this.renderGoalFlag(ctx);
    }
  }

  private renderGoalFlag(ctx: CanvasRenderingContext2D): void {
    // Enhanced Vietnamese flag with waving animation
    const flagX = this.goalX;
    const flagY = 380;
    const flagWidth = 50;
    const flagHeight = 30;
    
    // Flag pole with base
    ctx.fillStyle = '#8B4513';
    ctx.fillRect(flagX, flagY - 20, 6, 170);
    
    // Flag base
    ctx.fillStyle = '#654321';
    ctx.fillRect(flagX - 5, flagY + 145, 16, 8);
    
    // Create wavy flag effect
    ctx.save();
    
    // Flag background (red) with wave
    ctx.fillStyle = '#DA020E';
    ctx.beginPath();
    ctx.moveTo(flagX + 6, flagY);
    
    // Create wavy edges for more realistic flag movement
    for (let i = 0; i <= flagWidth; i += 3) {
      const waveY = flagY + Math.sin(this.flagWave + i * 0.15) * 3;
      ctx.lineTo(flagX + 6 + i, waveY);
    }
    
    // Bottom edge
    for (let i = flagWidth; i >= 0; i -= 3) {
      const waveY = flagY + flagHeight + Math.sin(this.flagWave + i * 0.15) * 3;
      ctx.lineTo(flagX + 6 + i, waveY);
    }
    
    ctx.closePath();
    ctx.fill();
    
    // Add flag shadow for depth
    ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
    ctx.beginPath();
    ctx.moveTo(flagX + 8, flagY + 2);
    for (let i = 0; i <= flagWidth - 2; i += 3) {
      const waveY = flagY + 2 + Math.sin(this.flagWave + i * 0.15) * 2;
      ctx.lineTo(flagX + 8 + i, waveY);
    }
    for (let i = flagWidth - 2; i >= 0; i -= 3) {
      const waveY = flagY + flagHeight + Math.sin(this.flagWave + i * 0.15) * 2;
      ctx.lineTo(flagX + 8 + i, waveY);
    }
    ctx.closePath();
    ctx.fill();
    
    // Yellow star in center with glow
    const starX = flagX + 6 + flagWidth / 2;
    const starY = flagY + flagHeight / 2 + Math.sin(this.flagWave) * 1.5;
    
    ctx.shadowColor = '#FFFF00';
    ctx.shadowBlur = 10;
    ctx.fillStyle = '#FFFF00';
    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
      const angle = (i * 144 - 90) * Math.PI / 180;
      const x = starX + Math.cos(angle) * 8;
      const y = starY + Math.sin(angle) * 8;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fill();
    ctx.shadowBlur = 0;
    
    ctx.restore();
    
    // Add Vietnamese text that appears periodically
    if (Math.sin(this.flagWave * 0.8) > 0.3) {
      ctx.fillStyle = '#FF0000';
      ctx.font = 'bold 14px Arial';
      ctx.textAlign = 'center';
      ctx.shadowColor = '#FFFFFF';
      ctx.shadowBlur = 3;
      ctx.fillText('VIỆT NAM', flagX + flagWidth/2 + 6, flagY - 15);
      ctx.fillText('VÔ ĐỊCH!', flagX + flagWidth/2 + 6, flagY + flagHeight + 25);
      ctx.shadowBlur = 0;
    }
  }

  checkGoalReached(playerX: number): boolean {
    if (!this.isBossLevel && playerX >= this.goalX - 20) {
      this.isComplete = true;
      return true;
    }
    return false;
  }

  removeCollectible(collectible: Collectible): void {
    const index = this.collectibles.indexOf(collectible);
    if (index > -1) {
      this.collectibles.splice(index, 1);
    }
  }

  removeEnemy(enemy: Enemy): void {
    const index = this.enemies.indexOf(enemy);
    if (index > -1) {
      this.enemies.splice(index, 1);
    }
  }
}
