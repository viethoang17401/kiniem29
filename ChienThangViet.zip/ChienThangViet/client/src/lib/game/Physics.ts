export interface GameObject {
  x: number;
  y: number;
  width: number;
  height: number;
  velocityX?: number;
  velocityY?: number;
}

export class Physics {
  static readonly GRAVITY = 0.8;
  static readonly MAX_FALL_SPEED = 12;
  static readonly FRICTION = 0.85;

  static applyGravity(object: GameObject): void {
    if (object.velocityY !== undefined) {
      object.velocityY += this.GRAVITY;
      if (object.velocityY > this.MAX_FALL_SPEED) {
        object.velocityY = this.MAX_FALL_SPEED;
      }
    }
  }

  static checkCollision(a: GameObject, b: GameObject): boolean {
    return (
      a.x < b.x + b.width &&
      a.x + a.width > b.x &&
      a.y < b.y + b.height &&
      a.y + a.height > b.y
    );
  }

  static checkCollisionTop(a: GameObject, b: GameObject): boolean {
    return (
      this.checkCollision(a, b) &&
      a.y + a.height - 10 <= b.y && // Object A is above object B
      (a.velocityY || 0) >= 0 // Object A is falling or stationary
    );
  }

  static checkCollisionSide(a: GameObject, b: GameObject): boolean {
    return (
      this.checkCollision(a, b) &&
      !(a.y + a.height - 10 <= b.y) // Not a top collision
    );
  }

  static resolveCollision(a: GameObject, b: GameObject): void {
    const overlapX = Math.min(a.x + a.width - b.x, b.x + b.width - a.x);
    const overlapY = Math.min(a.y + a.height - b.y, b.y + b.height - a.y);

    if (overlapX < overlapY) {
      // Horizontal collision
      if (a.x < b.x) {
        a.x = b.x - a.width;
      } else {
        a.x = b.x + b.width;
      }
      if (a.velocityX !== undefined) {
        a.velocityX = 0;
      }
    } else {
      // Vertical collision
      if (a.y < b.y) {
        a.y = b.y - a.height;
        if (a.velocityY !== undefined) {
          a.velocityY = 0;
        }
      } else {
        a.y = b.y + b.height;
        if (a.velocityY !== undefined) {
          a.velocityY = 0;
        }
      }
    }
  }

  static isOnGround(object: GameObject, platforms: GameObject[]): boolean {
    const groundCheckObject = {
      x: object.x,
      y: object.y + 1,
      width: object.width,
      height: object.height
    };

    for (const platform of platforms) {
      if (this.checkCollision(groundCheckObject, platform)) {
        return true;
      }
    }

    // Check if on ground level
    return object.y + object.height >= 550;
  }

  static distance(a: GameObject, b: GameObject): number {
    const dx = (a.x + a.width / 2) - (b.x + b.width / 2);
    const dy = (a.y + a.height / 2) - (b.y + b.height / 2);
    return Math.sqrt(dx * dx + dy * dy);
  }

  static getDirection(from: GameObject, to: GameObject): { x: number; y: number } {
    const dx = (to.x + to.width / 2) - (from.x + from.width / 2);
    const dy = (to.y + to.height / 2) - (from.y + from.height / 2);
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    if (distance === 0) return { x: 0, y: 0 };
    
    return {
      x: dx / distance,
      y: dy / distance
    };
  }

  static applyFriction(object: GameObject): void {
    if (object.velocityX !== undefined) {
      object.velocityX *= this.FRICTION;
      if (Math.abs(object.velocityX) < 0.1) {
        object.velocityX = 0;
      }
    }
  }
}
