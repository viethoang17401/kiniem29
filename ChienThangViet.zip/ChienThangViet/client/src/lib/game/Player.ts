import { Physics } from './Physics';

export class Player {
  x: number = 50;
  y: number = 400;
  width: number = 40;
  height: number = 60;
  velocityX: number = 0;
  velocityY: number = 0;
  health: number = 3;
  isOnGround: boolean = false;
  isInvincible: boolean = false;
  invincibilityTimer: number = 0;
  maxHealth: number = 3;
  speed: number = 5;
  jumpPower: number = 15;
  
  // Animation properties
  direction: 'left' | 'right' = 'right';
  animationFrame: number = 0;
  animationTimer: number = 0;
  isMoving: boolean = false;
  dustParticles: Array<{x: number, y: number, life: number}> = [];
  
  // Weapon system
  hasWeapon: boolean = true;
  weaponUpgraded: boolean = false;
  isShooting: boolean = false;
  shootCooldown: number = 0;
  bullets: Array<{x: number, y: number, vx: number, vy: number, upgraded: boolean, life: number, trail: Array<{x: number, y: number, life: number}>}> = [];

  constructor(x: number, y: number) {
    this.x = x;
    this.y = y;
  }

  update(keys: Set<string>, platforms: any[], deltaTime: number): void {
    // Handle input
    this.handleInput(keys);
    
    // Apply physics
    Physics.applyGravity(this);
    
    // Update position
    this.x += this.velocityX;
    this.y += this.velocityY;
    
    // Platform collision
    this.isOnGround = false;
    for (const platform of platforms) {
      if (Physics.checkCollision(this, platform)) {
        // Landing on top of platform
        if (this.velocityY > 0 && this.y < platform.y) {
          this.y = platform.y - this.height;
          this.velocityY = 0;
          this.isOnGround = true;
        }
      }
    }
    
    // Ground collision (bottom of screen)
    if (this.y > 550) {
      this.y = 550;
      this.velocityY = 0;
      this.isOnGround = true;
    }
    
    // Screen boundaries
    if (this.x < 0) this.x = 0;
    if (this.x > 760) this.x = 760;
    
    // Update invincibility
    if (this.isInvincible) {
      this.invincibilityTimer -= deltaTime;
      if (this.invincibilityTimer <= 0) {
        this.isInvincible = false;
      }
    }
    
    // Update animation
    this.updateAnimation(deltaTime);
  }

  private handleInput(keys: Set<string>): void {
    this.velocityX = 0;
    this.isMoving = false;
    
    // Movement
    if (keys.has('ArrowLeft') || keys.has('a') || keys.has('A')) {
      this.velocityX = -this.speed;
      this.direction = 'left';
      this.isMoving = true;
      // Create dust particles when running
      if (this.isOnGround && Math.random() < 0.3) {
        this.dustParticles.push({
          x: this.x + this.width / 2 + (Math.random() - 0.5) * 10,
          y: this.y + this.height - 5,
          life: 20
        });
      }
    }
    if (keys.has('ArrowRight') || keys.has('d') || keys.has('D')) {
      this.velocityX = this.speed;
      this.direction = 'right';
      this.isMoving = true;
      // Create dust particles when running
      if (this.isOnGround && Math.random() < 0.3) {
        this.dustParticles.push({
          x: this.x + this.width / 2 + (Math.random() - 0.5) * 10,
          y: this.y + this.height - 5,
          life: 20
        });
      }
    }
    
    // Jumping
    if ((keys.has('ArrowUp') || keys.has('w') || keys.has('W') || keys.has(' ')) && this.isOnGround) {
      this.velocityY = -this.jumpPower;
      this.isOnGround = false;
    }
  }
  
  handleMouseClick(mouseX: number, mouseY: number): void {
    if (!this.hasWeapon || this.shootCooldown > 0) return;
    
    this.shoot(mouseX, mouseY);
    this.shootCooldown = this.weaponUpgraded ? 150 : 300; // Faster shooting when upgraded
  }
  
  private shoot(targetX: number, targetY: number): void {
    const playerCenterX = this.x + this.width / 2;
    const playerCenterY = this.y + this.height / 2;
    
    // Calculate direction
    const dx = targetX - playerCenterX;
    const dy = targetY - playerCenterY;
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    if (distance === 0) return;
    
    const speed = 8;
    const bulletVx = (dx / distance) * speed;
    const bulletVy = (dy / distance) * speed;
    
    // Create bullet with trail
    this.bullets.push({
      x: playerCenterX,
      y: playerCenterY - 10, // Shoot from chest level
      vx: bulletVx,
      vy: bulletVy,
      upgraded: this.weaponUpgraded,
      life: 120, // Bullet lifetime
      trail: []
    });
    
    this.isShooting = true;
    setTimeout(() => {
      this.isShooting = false;
    }, 100);
  }

  private updateAnimation(deltaTime: number): void {
    this.animationTimer += deltaTime;
    if (this.animationTimer > 200) { // 200ms per frame
      this.animationFrame = (this.animationFrame + 1) % 4;
      this.animationTimer = 0;
    }
    
    // Update dust particles
    this.dustParticles = this.dustParticles.filter(particle => {
      particle.life--;
      particle.y -= 0.5;
      particle.x += (Math.random() - 0.5) * 2;
      return particle.life > 0;
    });
    
    // Update shooting cooldown
    if (this.shootCooldown > 0) {
      this.shootCooldown -= deltaTime;
    }
    
    // Update bullets
    this.bullets = this.bullets.filter(bullet => {
      // Add current position to trail
      bullet.trail.push({x: bullet.x, y: bullet.y, life: 10});
      
      bullet.x += bullet.vx;
      bullet.y += bullet.vy;
      bullet.life--;
      
      // Update trail
      bullet.trail = bullet.trail.filter(trailPoint => {
        trailPoint.life--;
        return trailPoint.life > 0;
      });
      
      // Remove bullets that go off screen or expire
      return bullet.x > -50 && bullet.x < 850 && bullet.y > -50 && bullet.y < 650 && bullet.life > 0;
    });
  }

  render(ctx: CanvasRenderingContext2D): void {
    ctx.save();
    
    // Render dust particles first (behind character)
    this.dustParticles.forEach(particle => {
      const alpha = particle.life / 20;
      ctx.fillStyle = `rgba(139, 115, 85, ${alpha * 0.6})`;
      ctx.fillRect(particle.x - 1, particle.y - 1, 2, 2);
    });
    
    // Flashing effect when invincible
    if (this.isInvincible && Math.floor(Date.now() / 100) % 2) {
      ctx.globalAlpha = 0.5;
    }
    
    // Calculate animation offset for running
    const runOffset = this.isMoving && this.isOnGround ? Math.sin(this.animationFrame) * 1 : 0;
    const jumpOffset = !this.isOnGround ? -2 : 0;
    
    // Draw Vietnamese soldier with enhanced design
    
    // Body (dark green uniform with details)
    ctx.fillStyle = '#1C3A1C'; // Darker, more professional green
    ctx.fillRect(this.x + 8, this.y + 20 + runOffset, 24, 30);
    
    // Uniform details (breast pockets)
    ctx.fillStyle = '#0F2F0F';
    ctx.fillRect(this.x + 10, this.y + 25 + runOffset, 6, 4);
    ctx.fillRect(this.x + 24, this.y + 25 + runOffset, 6, 4);
    
    // Belt
    ctx.fillStyle = '#8B4513';
    ctx.fillRect(this.x + 8, this.y + 42 + runOffset, 24, 3);
    
    // Belt buckle
    ctx.fillStyle = '#DAA520';
    ctx.fillRect(this.x + 18, this.y + 42 + runOffset, 4, 3);
    
    // Head (refined skin tone)
    ctx.fillStyle = '#FDBCB4';
    ctx.fillRect(this.x + 12, this.y + jumpOffset, 16, 20);
    
    // Military helmet (polished green with shine)
    ctx.fillStyle = '#2D5A2D';
    ctx.fillRect(this.x + 8, this.y - 5 + jumpOffset, 24, 15);
    
    // Helmet shine effect
    ctx.fillStyle = '#4A7C4A';
    ctx.fillRect(this.x + 10, this.y - 3 + jumpOffset, 20, 2);
    
    // Golden star on helmet (larger and more prominent)
    const starTime = Date.now() * 0.003;
    const starGlow = 0.5 + 0.5 * Math.sin(starTime);
    ctx.shadowColor = '#FFD700';
    ctx.shadowBlur = 3 + starGlow * 2;
    ctx.fillStyle = '#FFD700';
    ctx.beginPath();
    const starX = this.x + 20;
    const starY = this.y + 2 + jumpOffset;
    for (let i = 0; i < 5; i++) {
      const angle = (i * 144 - 90) * Math.PI / 180;
      const x = starX + Math.cos(angle) * 5; // Larger star
      const y = starY + Math.sin(angle) * 5;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fill();
    ctx.shadowBlur = 0;
    
    // Arms with movement animation
    const armSwing = this.isMoving ? Math.sin(this.animationFrame * 0.5) * 2 : 0;
    ctx.fillStyle = '#1C3A1C';
    ctx.fillRect(this.x + 2, this.y + 25 + runOffset + armSwing, 8, 20);
    ctx.fillRect(this.x + 30, this.y + 25 + runOffset - armSwing, 8, 20);
    
    // Hands
    ctx.fillStyle = '#FDBCB4';
    ctx.fillRect(this.x + 2, this.y + 43 + runOffset + armSwing, 8, 4);
    ctx.fillRect(this.x + 30, this.y + 43 + runOffset - armSwing, 8, 4);
    
    // Legs with running animation
    const legSwing = this.isMoving ? Math.sin(this.animationFrame * 0.7) * 3 : 0;
    ctx.fillStyle = '#1C3A1C';
    ctx.fillRect(this.x + 12, this.y + 50 + runOffset + legSwing, 8, 15);
    ctx.fillRect(this.x + 20, this.y + 50 + runOffset - legSwing, 8, 15);
    
    // Boots (polished black)
    ctx.fillStyle = '#000000';
    ctx.fillRect(this.x + 10, this.y + 60 + runOffset + legSwing, 12, 8);
    ctx.fillRect(this.x + 22, this.y + 60 + runOffset - legSwing, 12, 8);
    
    // Boot shine
    ctx.fillStyle = '#333333';
    ctx.fillRect(this.x + 10, this.y + 60 + runOffset + legSwing, 12, 2);
    ctx.fillRect(this.x + 22, this.y + 60 + runOffset - legSwing, 12, 2);
    
    // Face details (kind but determined expression)
    ctx.fillStyle = '#000000';
    // Eyes (bright and determined)
    ctx.fillRect(this.x + 14, this.y + 8 + jumpOffset, 2, 2);
    ctx.fillRect(this.x + 24, this.y + 8 + jumpOffset, 2, 2);
    
    // Eye shine (determined look)
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(this.x + 15, this.y + 8 + jumpOffset, 1, 1);
    ctx.fillRect(this.x + 25, this.y + 8 + jumpOffset, 1, 1);
    
    // Nose
    ctx.fillStyle = '#E8A589';
    ctx.fillRect(this.x + 19, this.y + 12 + jumpOffset, 2, 2);
    
    // Mouth (slight determined expression)
    ctx.fillStyle = '#8B4513';
    ctx.fillRect(this.x + 17, this.y + 15 + jumpOffset, 6, 1);
    
    // Eyebrows (showing determination)
    ctx.fillStyle = '#654321';
    ctx.fillRect(this.x + 13, this.y + 6 + jumpOffset, 4, 1);
    ctx.fillRect(this.x + 23, this.y + 6 + jumpOffset, 4, 1);
    
    // Weapon (rifle slung across shoulder)
    if (this.hasWeapon) {
      this.renderWeapon(ctx, runOffset, jumpOffset);
    }
    
    // Render bullets
    this.renderBullets(ctx);
    
    ctx.restore();
  }
  
  private renderWeapon(ctx: CanvasRenderingContext2D, runOffset: number, jumpOffset: number): void {
    ctx.save();
    
    // Weapon color (dark metal)
    const weaponColor = this.weaponUpgraded ? '#DAA520' : '#2F2F2F'; // Gold when upgraded
    
    // Rifle body (slung across back/shoulder)
    ctx.fillStyle = weaponColor;
    
    if (this.isShooting) {
      // Shooting position - rifle in hands
      if (this.direction === 'right') {
        // Rifle barrel pointing right
        ctx.fillRect(this.x + 32, this.y + 30 + runOffset + jumpOffset, 25, 4);
        // Rifle stock
        ctx.fillRect(this.x + 25, this.y + 28 + runOffset + jumpOffset, 8, 8);
        // Trigger guard
        ctx.strokeStyle = weaponColor;
        ctx.lineWidth = 1;
        ctx.strokeRect(this.x + 30, this.y + 32 + runOffset + jumpOffset, 4, 3);
      } else {
        // Rifle barrel pointing left
        ctx.fillRect(this.x - 17, this.y + 30 + runOffset + jumpOffset, 25, 4);
        // Rifle stock
        ctx.fillRect(this.x + 7, this.y + 28 + runOffset + jumpOffset, 8, 8);
        // Trigger guard
        ctx.strokeStyle = weaponColor;
        ctx.lineWidth = 1;
        ctx.strokeRect(this.x + 6, this.y + 32 + runOffset + jumpOffset, 4, 3);
      }
    } else {
      // Slung position - across shoulder
      // Rifle strap
      ctx.strokeStyle = '#8B4513';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(this.x + 8, this.y + 20 + runOffset + jumpOffset);
      ctx.lineTo(this.x + 32, this.y + 35 + runOffset + jumpOffset);
      ctx.stroke();
      
      // Rifle body (diagonal across back)
      ctx.fillStyle = weaponColor;
      ctx.save();
      ctx.translate(this.x + 20, this.y + 25 + runOffset + jumpOffset);
      ctx.rotate(Math.PI / 6); // 30 degree angle
      ctx.fillRect(-12, -2, 24, 3);
      ctx.fillRect(-15, -3, 6, 5); // Stock
      ctx.restore();
    }
    
    // Weapon glow effect when upgraded
    if (this.weaponUpgraded) {
      ctx.shadowColor = '#FFD700';
      ctx.shadowBlur = 5;
      ctx.fillStyle = '#FFD700';
      if (this.isShooting) {
        if (this.direction === 'right') {
          ctx.fillRect(this.x + 55, this.y + 31 + runOffset + jumpOffset, 3, 2);
        } else {
          ctx.fillRect(this.x - 18, this.y + 31 + runOffset + jumpOffset, 3, 2);
        }
      }
      ctx.shadowBlur = 0;
    }
    
    ctx.restore();
  }
  
  private renderBullets(ctx: CanvasRenderingContext2D): void {
    this.bullets.forEach(bullet => {
      ctx.save();
      
      // Render bullet trail first
      bullet.trail.forEach((trailPoint, index) => {
        const alpha = trailPoint.life / 10;
        const size = alpha * 2;
        ctx.fillStyle = `rgba(255, 215, 0, ${alpha * 0.6})`;
        ctx.beginPath();
        ctx.arc(trailPoint.x, trailPoint.y, size, 0, Math.PI * 2);
        ctx.fill();
      });
      
      if (bullet.upgraded) {
        // Star bullet - golden star that glows
        ctx.shadowColor = '#FFD700';
        ctx.shadowBlur = 12;
        ctx.fillStyle = '#FFD700';
        
        ctx.save();
        ctx.translate(bullet.x, bullet.y);
        ctx.rotate(Date.now() * 0.015);
        
        // Draw star shape with stronger glow
        ctx.beginPath();
        for (let i = 0; i < 5; i++) {
          const angle = (i * 144 - 90) * Math.PI / 180;
          const x = Math.cos(angle) * 5;
          const y = Math.sin(angle) * 5;
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.closePath();
        ctx.fill();
        
        // Add sparkle effect
        ctx.fillStyle = '#FFF';
        ctx.beginPath();
        ctx.arc(0, 0, 1, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.restore();
      } else {
        // Regular bullet - golden with intense glow
        ctx.shadowColor = '#FFD700';
        ctx.shadowBlur = 8;
        ctx.fillStyle = '#DAA520';
        
        // Bullet body with metallic shine
        ctx.fillRect(bullet.x - 3, bullet.y - 1.5, 6, 3);
        
        // Bullet tip - brighter
        ctx.fillStyle = '#FFD700';
        ctx.fillRect(bullet.x + 3, bullet.y - 1, 3, 2);
        
        // Muzzle flash effect at bullet tip
        ctx.fillStyle = '#FFF8DC';
        ctx.beginPath();
        ctx.arc(bullet.x + 4, bullet.y, 1.5, 0, Math.PI * 2);
        ctx.fill();
      }
      
      ctx.shadowBlur = 0;
      ctx.restore();
    });
  }
  
  upgradeWeapon(): void {
    this.weaponUpgraded = true;
  }
  
  getBullets() {
    return this.bullets;
  }
  
  removeBullet(bulletIndex: number): void {
    if (bulletIndex >= 0 && bulletIndex < this.bullets.length) {
      this.bullets.splice(bulletIndex, 1);
    }
  }

  takeDamage(amount: number = 1): void {
    if (!this.isInvincible) {
      this.health = Math.max(0, this.health - amount);
      this.makeInvincible(2000); // 2 seconds of invincibility
    }
  }

  heal(amount: number = 1): void {
    this.health = Math.min(this.maxHealth, this.health + amount);
  }

  makeInvincible(duration: number): void {
    this.isInvincible = true;
    this.invincibilityTimer = duration;
  }

  getBounds() {
    return {
      x: this.x,
      y: this.y,
      width: this.width,
      height: this.height
    };
  }
}
