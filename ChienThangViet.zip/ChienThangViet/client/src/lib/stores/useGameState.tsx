import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';

export type GameState = 'menu' | 'playing' | 'paused' | 'gameOver' | 'victory';

interface GameStateStore {
  // Game state
  gameState: GameState;
  score: number;
  health: number;
  level: number;
  lives: number;
  
  // Actions
  setGameState: (state: GameState) => void;
  addScore: (points: number) => void;
  setHealth: (health: number) => void;
  setLevel: (level: number) => void;
  setLives: (lives: number) => void;
  resetGame: () => void;
  initializeGame: () => void;
}

export const useGameState = create<GameStateStore>()(
  subscribeWithSelector((set, get) => ({
    // Initial state
    gameState: 'menu',
    score: 0,
    health: 3,
    level: 1,
    lives: 3,
    
    // Actions
    setGameState: (state: GameState) => {
      console.log(`Game state changed to: ${state}`);
      set({ gameState: state });
    },
    
    addScore: (points: number) => {
      set((state) => ({ 
        score: state.score + points 
      }));
    },
    
    setHealth: (health: number) => {
      set({ health: Math.max(0, health) });
    },
    
    setLevel: (level: number) => {
      set({ level });
    },
    
    setLives: (lives: number) => {
      set({ lives: Math.max(0, lives) });
    },
    
    resetGame: () => {
      set({
        score: 0,
        health: 3,
        level: 1,
        lives: 3,
        gameState: 'menu'
      });
    },
    
    initializeGame: () => {
      console.log('Game initialized');
      set({
        score: 0,
        health: 3,
        level: 1,
        lives: 3
      });
    }
  }))
);
