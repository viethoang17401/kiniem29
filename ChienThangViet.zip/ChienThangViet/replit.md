# Overview

This is a Vietnamese-themed Mario-style platformer game called "Mario Bộ Đội vs Cali" created to commemorate the 80th anniversary of Vietnam's National Day. The application is a full-stack web game built with React on the frontend, Express.js on the backend, and includes a custom 2D game engine built with HTML5 Canvas. The game features multiple levels, enemies, collectibles, boss fights, and a complete game state management system with audio support.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend is built using React with TypeScript and uses a modern component-based architecture:
- **Game Engine**: Custom 2D game engine using HTML5 Canvas for rendering
- **State Management**: Zustand for global state management with separate stores for game state and audio
- **UI Framework**: Radix UI components with Tailwind CSS for styling
- **Build Tool**: Vite for development and production builds with hot module replacement

## Backend Architecture
The backend follows a minimal Express.js REST API pattern:
- **Server Framework**: Express.js with TypeScript
- **Storage Layer**: Abstracted storage interface with in-memory implementation (MemStorage)
- **Development Setup**: Vite middleware integration for development with production static file serving

## Game Architecture
The game uses a custom entity-component system:
- **GameEngine**: Main game loop handling updates, rendering, and state management
- **Physics System**: Custom physics engine with gravity, collision detection, and response
- **Entity Classes**: Player, Enemy, Boss, Collectible classes with update/render cycles
- **Level System**: Procedurally generated levels with platforms, enemies, and collectibles

## Data Storage
- **Database**: PostgreSQL with Drizzle ORM for schema management and migrations
- **Connection**: Neon Database serverless PostgreSQL connection
- **Schema**: User authentication system with username/password fields
- **Development Storage**: In-memory storage implementation for rapid development

## Audio System
- **Audio Management**: Zustand store managing background music and sound effects
- **File Support**: MP3, OGG, and WAV audio file support through Vite asset pipeline
- **Mute Control**: Global mute/unmute functionality with audio state persistence

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL database hosting
- **Drizzle ORM**: Type-safe database schema and query management

## UI Components
- **Radix UI**: Comprehensive accessible component library
- **Tailwind CSS**: Utility-first CSS framework for styling
- **Lucide React**: Icon library for UI elements

## Game Development
- **React Three Fiber**: 3D rendering capabilities (available but not actively used)
- **GLSL Shader Support**: Custom shader support through Vite plugin

## Development Tools
- **TypeScript**: Type safety across frontend and backend
- **Vite**: Build tool with HMR and development server
- **ESBuild**: Production backend bundling

## Audio Assets
- Background music and sound effects loaded from `/sounds/` directory
- Support for overlapping sound playback for game effects

## Build and Deployment
- **Production Build**: Vite frontend build with ESBuild backend bundling
- **Asset Handling**: Large model and audio file support through Vite configuration
- **Font Assets**: Inter font family with local font serving